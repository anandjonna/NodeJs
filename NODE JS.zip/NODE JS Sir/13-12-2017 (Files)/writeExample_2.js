var http = require("http");
var fs   = require("fs");
var server = http.createServer(function (req,res) {
    fs.writeFile("sample.txt","Welcome to NodeJS...!",
                            function (err) {
        if(err){
            console.log("Error !");
        }else{
            fs.readFile(__dirname+"/sample.txt",
                            function (err,data) {
               if(err){
                   console.log("Error !");
               } else{
                   res.end(data.toString());
               }
            });
        }
    });
});
server.listen(8080);
console.log("server listening the port no.8080");

