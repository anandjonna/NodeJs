var http = require("http");
var fs = require("fs");

var server = http.createServer(function (req,res) {
    fs.open(__dirname+"/emp.json","r+",function (err,fd) {
        if(err){
            res.end("Error !");
        }else{
            res.end("File Opened Successfully !");
        }
    });
});

server.listen(8080);
console.log("server listening the port no.8080");