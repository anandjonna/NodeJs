//import modules
var http = require("http");
var fs = require("fs");

//create the server
var server = http.createServer(function (req,res) {
    //open the file
    fs.open(__dirname+"/sample.txt","r+",function (err,fd) {
        //truncate the file
        fs.ftruncate(fd,10,function (err) {
            //read the file
            fs.readFile(__dirname+"/sample.txt",function (err,data) {
                if(err){
                    throw err;
                }else{
                    res.write(data.toString());
                    fs.close(fd,function (err) {
                        if(err){
                            throw err;
                        }else{
                            fs.unlink("sample.txt",function (err) {
                                if(err){
                                    throw err;
                                }else{
                                    res.end("");
                                }
                            });
                        }
                    });
                }
            });
        });
    });
});

//assign the port no.
server.listen(8080);
console.log("server listening the port no.8080");