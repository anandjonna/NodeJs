//import modules
var http = require("http");
var fs   = require("fs");
//create the server
var server = http.createServer(function (req,res) {
    //appending the data asynchronously
    /*fs.appendFile("sample.txt","Hello....!",encoding='utf8',
                        function (err) {
        if(err){
            throw err;
        }else{
            res.end("data appended successfully !");
        }
    });*/
    //appending data asynchronously
    fs.appendFileSync("sample.txt","Welcome...!",encoding='utf8');
    res.end("Data Appended Synchronously !");
});
//assign the port no.
server.listen(8080);
console.log("server listening the port no.8080");

