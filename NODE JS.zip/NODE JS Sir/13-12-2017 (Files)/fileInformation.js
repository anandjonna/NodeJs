var http = require("http");
var fs   = require("fs");

var server = http.createServer(function (req,res) {
    fs.stat(__dirname+"/emp.json",function (err,data) {
        if(err){
            console.log("Error !");
        }else{
            res.end(data.isFile()+"...."+data.isDirectory());
        }
    });
});

server.listen(8080);
console.log("server listening the port no.8080");