//import modules
var http = require("http");
var fs   = require("fs");

//create the server
var server = http.createServer(function (req,res) {
    //open the file
    fs.open(__dirname+"/emp.json","r+",function (err,fd) {
        if(err){
            throw err;
        }else{
            res.write("File Opened Successfully !");
            //read the file asynchronously
            fs.readFile(__dirname+"/emp.json",
                                        function (err,data) {
               if(err){
                   throw err;
               }else{
                   res.write(data.toString());
                   //close the file
                   fs.close(fd,function (err) {
                        if(err){
                            throw err;
                        } else{
                            res.end("File Closed Successfully !");
                        }
                   });
               }
            });
        }
    });
});

//assign the port no
server.listen(8080);