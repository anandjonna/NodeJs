//import modules
//'express' module used to develop the Rest API
var express = require("express");

//import body-parser module
/*
'body-parser' module used to read the "post parameters"
  as well as the set the "MIME Type".
*/
var bodyparser = require("body-parser");


//create the Rest Object
// 'app' object used to develop the Rest API.
var app = express();


//set the MIME Type
app.use(bodyparser.json());
bodyparser.urlencoded({'extended':false});


//create post request
app.post("/login",function (req,res) {
    //reading the post parameters
    /*"body" is the predefined property in "body-parser"
    module used to read the post parameters*/
    var uname = req.body.uname;
    var upwd = req.body.upwd;
    if(uname == "admin" && upwd=="admin"){
        res.send({"login":"success"});
    }else{
        res.send({"login":"fail"});
    }
});
//assign the port no.
app.listen(8080);
console.log("server listening the port no.8080");
