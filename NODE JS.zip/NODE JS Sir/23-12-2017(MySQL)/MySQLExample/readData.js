var db = require("./db-config");
var connection = db.getConnection();
connection.connect();
connection.query("select * from products",function (err,recordsArray,fields) {
    if(err){
        console.log(err);
        return;
    }
    console.log(recordsArray);
});