var db = require("./db-config");
var connection = db.getConnection();
connection.connect();
connection.query("create table products(name varchar(20), cost integer)",
        function (err,result) {
    if(err){
        console.log(err);
        return
    }else{
        console.log("Table Created Successfully !");
    }
});