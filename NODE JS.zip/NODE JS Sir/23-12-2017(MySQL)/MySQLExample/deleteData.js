var db = require("./db-config");
var connection = db.getConnection();
connection.connect();
connection.query("delete from products",function (err,result) {
    if(err){
        console.log(err);
        return;
    }else{
        console.log("Data Deleted Successfully !");
    }
});