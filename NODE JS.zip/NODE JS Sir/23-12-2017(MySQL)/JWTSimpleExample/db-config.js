var mysql = require("mysql");
var config = require("./config");
var dbconn = {
    host:config.host,
    user:config.user,
    password:config.password,
    database:config.database,
    connectionLimit:config.connectionLimit
};
module.exports = {
    "getPool":function () {
        return mysql.createPool(dbconn);
    }
};