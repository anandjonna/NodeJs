module.exports={
    host:"localhost",
    user:"root",
    password:"root",
    database:"angular5",
    connectionLimit:100
};