//import express module
var express = require("express");
//create the router object
var router = express.Router();

//default request
router.get("/",function (req,res) {
    res.redirect("/login.html");
});

//get request
router.get("/login",function (req,res) {
   var uname = req.query.uname;
   var upwd  = req.query.upwd;
   if(uname == "admin" && upwd == "admin"){
       res.send({"login":"success"});
   }else{
       res.send({"login":"fail"})
   }
});
//post request
router.post("/login",function (req,res) {
    var uname = req.body.uname;
    var upwd = req.body.upwd;
    if(uname == "admin" && upwd == "admin"){
        res.send({"login":"success"});
    }else{
        res.send({"login":"fail"});
    }
});
//exporting the module
module.exports = router;