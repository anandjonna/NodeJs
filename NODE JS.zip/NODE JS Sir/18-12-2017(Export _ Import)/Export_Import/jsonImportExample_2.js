var obj = require("./functionExportExample");
console.log(obj);