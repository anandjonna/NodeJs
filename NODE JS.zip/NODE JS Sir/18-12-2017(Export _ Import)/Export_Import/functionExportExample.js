/*
module.exports = {
    "login":login
};
function login() {
    return "Welcome...!";
}*/


//function exporting
/*
module.exports = function () {
    return "Welcome...!";
};*/


//named function exporting
/*
module.exports = my_fun;
function my_fun() {
    return "Welcome...!";
}*/

//exporting the variable
var data = "Data From DataBase Soon...!"
module.exports = data;