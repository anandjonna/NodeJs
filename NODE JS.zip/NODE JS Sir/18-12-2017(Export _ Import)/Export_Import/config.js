module.exports={
    "user":"root",
    "password":"root",
    "host":"localhost",
    "database":"my_db",
    "connectionLimit":10,
    "debug":true
};