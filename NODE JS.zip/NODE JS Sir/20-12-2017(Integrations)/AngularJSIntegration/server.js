//import modules
var express = require("express");
var bodyparser = require("body-parser");

//create the Rest Object
var app = express();

//set the JSON As the MIME Type
app.use(bodyparser.json());

//Secuirity to read POST Parameters
bodyparser.urlencoded({extended:false});

//Deploy the Project
app.use(express.static(__dirname+"/../AngularJSIntegration"));

//create the Default Request
app.get("/",function (req,res) {
    //launching the default page
    res.redirect("/index.html");
});

//create the POST Request
app.post("/login",function (req,res) {
    var uname = req.body.uname;
    var upwd  = req.body.upwd;
    if(uname == "admin" && upwd == "admin"){
        res.send({"login":"success !"});
    }else{
        res.send({"login":"fail !"});
    }
});

app.listen(8080);
console.log("server listening the port no.8080");