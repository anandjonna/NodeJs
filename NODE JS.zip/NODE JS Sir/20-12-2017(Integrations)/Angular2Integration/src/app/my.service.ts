import {Injectable} from "@angular/core";
import {Http,Response} from "@angular/http";
import "rxjs/add/operator/map";
@Injectable()
export class MyService{
  data:any;
  constructor(private __http:Http){

  }
  getData(obj){
    return this.__http.post("http://localhost:8080/login",obj)
      .map((res:Response)=>res.json());
  }
}
