var http=require("http");
var url=require("url");
var server=http.createServer(function(req,res){
    res.writeHead(200,{'content-type':'text/html'});
    var obj=url.parse(req.url,true).query;
    var uname=obj.uname;
    var upwd=obj.upwd;
    if(uname=="admin" && upwd=="admin"){
        res.write("<h1>Login sucees !</h1>");
    }
    else{
        res.write("<h1>login fail</h1>");
    }
    res.end();
});
server.listen(8040);
console.log("server listening the port no 8040");