var http = require("http");
var fs = require("fs");
var server = http.createServer(function(req,res){
    fs.open("class.txt","r+",function(err,fd){
        if(err){
            console.log("Error while opening the file");
        }
        else{
            res.write("Open file is successful");
            res.end();
        }
    });
});
server.listen(8080);
console.log("server listening the port no.8080");