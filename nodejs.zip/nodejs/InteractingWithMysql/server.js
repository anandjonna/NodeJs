var express = require("express");
var connection = require("./connection");
var app = express();
var conn = connection.getConnection();
conn.connect();
app.get("/",function(req,res){
    conn.query("create table products(p_id integer, p_name varchar(20),p_cost integer)",
        function (err) {
        if(err){
            console.log("table not created");
        }
        else{
            res.send("table  created successfully");
        }

        });
});
app.listen(8080);
console.log("server listening the port no.8080");