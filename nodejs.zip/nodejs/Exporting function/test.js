module.exports = function(){
    return{
        "host":"localhost",
        "user":"root",
        "password":"root",
        "database":"Angular5",
        "connectionLimit":10
    };
};