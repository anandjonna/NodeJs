var my_fun = require("./test");
var http = require("http");

var server = http.createServer(function(req,res){
    res.writeHead(200,{'content-Type':'text/html'})
    var obj = my_fun();
    res.write("<h1>host......."+obj.host+ "</h1>");
    res.write("<h1>user......."+obj.user+ "</h1>");
    res.write("<h1>password......."+obj.password +"</h1>");
    res.write("<h1>database......."+obj.database +"</h1>");
    res.write("<h1>connection limit......."+obj.connectionLimit +"</h1>");
    res.end();
});
server.listen(8080);
console.log("server listening the port no.8080");