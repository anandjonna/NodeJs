var express = require("express");
var connection = require("./connection");
var app = express();
app.use(express.static(__dirname+"/../insert"));
var conn = connection.getConnection();
conn.connect();
app.get("/insert",function(req,res){
    var pid = req.param("pid");
    var pname = req.param("pname");
    var pcost = req.param("pcost");
    var sql = "insert into products values("+pid+","+"'"+pname+"'"+","+pcost+")";
    conn.query(sql,function (err) {
            if(err){
                console.log("table not inserted");
            }
            else{
                res.send("table  inserted successfully");
            }

        });
});
app.listen(8080);
console.log("server listening the port no.8080");