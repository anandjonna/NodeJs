module.exports={
    "host":"localhost",
    "user":"root",
    "password":"anand",
    "database":"demo"
};