var config = require("./config");
var mysql = require("mysql");
module.exports={
    "getConnection":function(){
        return mysql.createConnection({
            host:config.host,
            user:config.user,
            password:config.password,
            database:config.database
            // port : config.port

        });

    }
};