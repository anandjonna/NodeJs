var express = require("express");
var connection = require("./connection");
var app = express();
var pool = connection.getpool();
app.get("/",function (req,res) {
    pool.getConnection(function (err,connection) {
        connection.query("select * from products",function(err,recordsArray,fields){
            res.send(recordsArray);
        });

    })

});
    app.listen(8080);
    console.log("server listening the port no.8080");
