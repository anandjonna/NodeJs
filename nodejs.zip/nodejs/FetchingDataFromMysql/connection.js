var mysql=require("mysql");
var config = require("./config");
module.exports={
    "getpool":function () {
        return mysql.createPool({
            "host":config.host,
            "user":config.user,
            "password":config.password,
            "database":config.database,
            "connectionLimit":config.connectionLimit
        })

    }
};