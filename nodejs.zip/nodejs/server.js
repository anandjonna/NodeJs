//import http module
var http=require("http");
//create the server
var server=http.createServer(function(req,res){
    res.writeHead(1000,{'content-type':'text/html'});
    res.write("welcome to first application");
    res.end();
});
server.listen(8080);
console.log("server listening the port no:8080");