var config1= require("./config1");
var mysql = require("mysql");
module.exports={
    "getconnnection":function(){
        return mysql.createConnection({
           host:config1.host,
            user:config1.user,
            password:config1.password,
            database:config1.database

        });
    }
};
