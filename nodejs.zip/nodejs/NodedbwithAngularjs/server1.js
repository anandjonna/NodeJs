var express = require("express");
var connection = require("./connection");
var app = express();
app.use(express.static(__dirname+"/../Integrations"));
var conn =connection.getConnection();
conn.connect();
app.get("/fetch",function (req,res) {
   conn.query("select * from products",function(err,recordsArray,fields){
       if(err){
           console.log("Error while fetching the data from database");
       }else{
           res.send(recordsArray);
       }
   });

});
app.listen(8090);
console.log("server listening the port no.8090");