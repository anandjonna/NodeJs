var express = require("express");
var connection1 = require("./connection1");
var app = express();
app.use(express.static(__dirname+"/../Integrations"));
var conn = connection1.getconnnection();
conn.connect();
app.use("/read",function(req,res){
    conn.query("select p_name from products",function(err,recordsArray,fields){
       if(err){
           console.log("Error while reading data from database");
       } else{
           res.send(recordsArray);
       }
    });
});
app.listen(8020);
console.log("server listening the port no.8020");