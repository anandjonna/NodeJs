var express = require("express");
var mongodb = require("mongodb");
var app = express();
var nareshit = mongodb.MongoClient;
app.get("/products",function (req,res) {
    nareshit.connect("mongodb://localhost:27017/demo",function (err,db) {
        db.collection("products").find().toArray(function (err,array) {
            res.send(array);
        });

    });

});
app.listen(8080);
console.log("server listening the port no.8080");