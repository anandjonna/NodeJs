var express = require("express");
var app = express();
app.get("/login",function (req,res) {
   var uname = req.param("uname");
   var upwd = req.param("upwd");
   if(uname == "admin" && upwd =="admin"){
       res.send({'login':'success'});
   }
   else{
       res.send({'login':'fail'});
   }
});
app.listen(8090);
console.log("server listening the port no.8090");