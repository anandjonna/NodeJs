var http = require ("http");
var fs = require ("fs");

var server = http.createServer(function(req,res){
    fs.writeFile("sample.txt","hi anand",function(err){
        if(err){
            res.write("Error while writing the data to the file.");
        }
        else{
            res.write("Data write to the file succesfully....");
        }
        res.end();

    });
});
server.listen(8050);
console.log("server listening the port no.8050");