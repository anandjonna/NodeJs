var http = require ("http");
var fs = require ("fs");

var server = http.createServer(function(req,res){
    fs.writeFileSync("sample.txt","Hello......");
    res.write("Data write succesfully.... ");
    res.end();
});
server.listen(8060);
console.log("Server listening the port no.8060");