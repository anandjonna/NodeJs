var http = require("http");
var fs = require("fs");
var server = http.createServer(function(req,res){
    fs.readFile("sample.json",function(err,data) {
        if(err){
            console.log("Error while reading data from file.");
        }
        else {
            res.write(data);
            res.end();
        }
    });
    });
server.listen(8080);
console.log("server listening the port no 8080");