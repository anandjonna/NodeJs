var http = require("http");
var fs = require("fs");

var server = http.createServer(function(req,res){
    var data = fs.readFileSync("sample.json");
    res.write(data);
    res.end();
});
server.listen(8040);
console.log("server listening the port no 8040");