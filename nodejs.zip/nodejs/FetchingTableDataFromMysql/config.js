module.exports={
    "connectionLimit":10,
    "host":"localhost",
    "user":"root",
    "password":"anand",
    "database":"demo"
}