var express = require("express");
var bodyparser = require("body-parser");
var app =express();
app.use(bodyparser.urlencoded({"extended":true}));
app.post("/login",function (req,res) {
   var uname = req.body.uname;
   var upwd = req.body.upwd;
   if(uname == "admin" && upwd == "admin"){
       res.send("login successfully");
   }else{
       res.send("login fail");
   }

});
app.listen(8080);
console.log("server listening the  port no.8080");