var express = require("express");
var bodyparser = require("body-parser");
var app = express();
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({"extended":false}));
app.post("/login",function (req,res) {
    var uname = req.body.uname;
    var upwd = req.body.upwd;
    if(uname == "admin" && upwd == "admin"){
        res.send("login succesfull");
    }else{
        res.send("login fail");
    }

});
app.listen(8090);
console.log("server listening the port no.8090");