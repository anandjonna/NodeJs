var jwt = require("jwt-simple");
module.exports=function(arg1,arg2,password){
    return jwt.encode({'key1':arg1,'key2':arg2},password);
};