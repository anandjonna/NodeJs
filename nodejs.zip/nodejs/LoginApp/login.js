var express = require("express");
var router = express.Router();
var generateToken = require("./generateToken");
var connection = require("./connection");
var conn = connection.getConnection();
conn.connect();
router.post("/signin",function(req,res){
   var uname=req.body.uname;
   var upwd=req.body.upwd;
   console.log(uname);
   console.log(upwd);
   con.query("select * from login_details where uname='"+uname+"' and upwd ='"+upwd+"'",
       function(err,recordArray,fields){
       if(recordArray.length >0){
           var token=generateToken(uname,upwd,"hr@tcs.com");
           res.send({"login":"succes","token":token});
       }else{
           res.send({"login":"fail"});
       }
       });
});
module.exports=router;