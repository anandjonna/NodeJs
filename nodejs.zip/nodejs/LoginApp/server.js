var express = require("express");
var bodyparser=require("body-parser");
var app = express();
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({"extended":true}));
var login = require("./login");
app.use("/login",login);
app.listen(8080);
console.log("server listening the port no .8080");