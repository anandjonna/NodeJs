var express = require("express");
var developer1 = require("./developer1");
var developer2 = require("./developer2");
var app = express();
app.use("/developer1",developer1);
app.use("/developer2",developer2);

app.get("/",function(req,res){
   res.send({'message':'main developer default parameter'});
});
app.get("/main",function(req,res){
    res.send({'message':'developer main'});
});
app.listen(8080);
console.log("server listening the port no.8080");