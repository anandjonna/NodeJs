var express = require("express");
var router = express.Router();
router.post("/",function(req,res){
    res.send({'message':'welcome to developer 2 request'});
});
router.post("/dev2",function(req,res) {
    res.send({'message':'welcome to developer 2 dev2 request'});
});
module.exports=router;