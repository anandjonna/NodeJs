var fs = require("fs");
fs.open("sample.txt","r+",function(err,fd){
    if(err){
        console.log("Error while opening the file");
    }
    else{
        console.log("file opening successful");
        fs.readFile("sample.txt",function(err,data){
           if(err){
               console.log("Error while reading the file");
           }
           else{
               console.log("file reading success");
               fs.writeFile("sample.txt","Hello",function(err){
                   if(err){
                       console.log("Error while writing data to file");
                   }
                   else{
                       console.log("File writing successful");
                       fs.appendFile("sample.txt","Anand",function(err){
                           if(err){
                               console.log("Error while append data to the file");
                           }
                           else{
                               console.log("File append data to the successful");
                               fs.close(fd,function(err){
                                   if(err){
                                       console.log("Error while closing the file");
                                   }
                                   else{
                                       console.log("file closing is successful");
                                       fs.unlink("sample.txt",function(err){
                                           if(err){
                                               console.log("Error while deleting the file");
                                           }
                                           else{
                                               console.log("file deleting successful");
                                           }
                                       });
                                   }
                               })
                           }
                       })
                   }
               })
           }
        });
    }
});