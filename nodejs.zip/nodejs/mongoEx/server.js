var express = require("express");
var mongodb = require("mongodb");
var app = express();
var nareshit = mongodb.MongoClient;
app.get("/insert",function (req,res) {
    var pid = req.param("pid");
    var pname = req.param("pname");
    var pcost = req.param("pcost");
   nareshit.connect("mongodb://localhost:27017/demo",function (err,db) {
       if(err){
           console.log("Error while connecting demo");
       }else{
           db.collection("products").insert({"p_id":pid,"p_name":pname,"p_cost":pcost},function(err) {
               if(err){
                   console.log("Error while inserting the data");
               }else{
                   res.send("data inserted succesfully");
               }

           });
       }

   });

});
app.listen(8080);
console.log("serever listening the port no.8080");