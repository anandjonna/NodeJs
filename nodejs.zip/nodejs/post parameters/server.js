var http = require("http");
var qs = require("querystring");
var server=http.createServer(function(req,res){

    var body="";
    req.on("data",function(data){
    body+=data;
    });
    req.on("end",function(){
       var obj=qs.parse(body);
       var uname=obj.uname;
       var upwd=obj.upwd;
       if(uname=="admin" && upwd=="admin"){
           res.write("<h1>Login success!</h1>");
       }
       else{
           res.write("<h1>Login Fail!</h1>");
       }
       res.end();
    });
    });
    server.listen(8080);
    console.log("Server listening the port no 8080");
