var express = require("express");
var mongodb = require("mongodb");
var app = express();
var nareshit = mongodb.MongoClient;
app.get("/products",function (req,res) {
    nareshit.connect("mongodb://localhost:27017/demo",function (err,db) {
       if(err){
           console.log("Error while connecting mongodb");
       } else{
           db.collection("products").find().toArray(function(err,array){
               if(err){
                   console.log("Error while creating the array");
               }
               else{
                   res.send(array);
               }
           });
       }

    });

});
app.listen(8080);
console.log("server listening the port no.8080");