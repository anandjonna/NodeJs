var http = require("http");
var fs = require ("fs");

var server = http.createServer(function(req,res){
    fs.appendFile("sample.txt","me....",function(err){
        if(err){
            res.write("Error while writing data to the file");
        }
        else{
            res.write("Data appended successfully");
        }
        res.end();
    });


});
server.listen(4050);
console.log("server lisstening the port no.4050");