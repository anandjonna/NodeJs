var http = require("http");
var fs = require("fs");

var server = http.createServer(function(req,res){
    fs.appendFileSync("sample.txt","welcome......!   ");
    res.write("Data appended to the file succesfully");
    res.end();
});
server.listen(8020);
console.log("server listening the port no.8020");