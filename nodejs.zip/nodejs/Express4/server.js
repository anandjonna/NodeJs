var express = require("express");
var app = express();
app.get("/login/:uname/:upwd",function(req,res){
    var uname = app.params.uname ;
    var upwd = app.params.upwd;
    if(uname ==  "admin"&&upwd == "admin"){
        res.send({'login':'success'});

    }
    else{
        res.send({'login': 'fail'});
    }
});
app.listen(8080);
console.log("server listening the port no.8080");