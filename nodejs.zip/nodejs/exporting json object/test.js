module.exports = {
    "getmysqlconnection":function(){
        return "my sql connection soon .....!";
    },
    "getmongodbconnection":function(){
        return "my mongodb connection soon.......!";
    },
    "getORMconnection":function(){
        return "my ORM connection soon  ........";
    }
};