var my_obj = require("./test");
var http = require("http");

var server = http.createServer(function(req,res){
    res.writeHead(200,{'content-Type':'text/html'});
    res.write(my_obj.getmysqlconnection()+"<br>");
    res.write(my_obj.getmongodbconnection()+"<br>");
    res.write(my_obj.getORMconnection()+"<br>");
    res.end();
});
server.listen(8080);
console.log("server listening the port no.8080")