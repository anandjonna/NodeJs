var express = require("express");
var app = express();
app.get("/",function(req,res){
    res.send({'message':'welcome to default get request'});
});

app.get("/getRequest",function(req,res){
    res.send({'message':'welcome to get request.......'});
});

app.post("/",function(req,res){
   res.send({'message':'welcome to post request'});
});
app.post("/postRequest",function(req,res){
    res.send({'message':'welcome to post parameters......'});
});
app.listen(8080);
console.log("server listening the port no 8080.")